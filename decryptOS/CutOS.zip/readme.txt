1) Open "Developer Command Prompt for VS" or "x64 Native Tools Command Prompt for VS" from your Start menu
2) Navigate to source directory
3) Run: "cl /EHsc /O2 CutOS.cpp"