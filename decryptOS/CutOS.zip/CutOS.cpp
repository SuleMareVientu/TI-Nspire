#include <iostream>
#include <fstream>
#include <vector>
#include <cstdint>
#include <string>
#include <windows.h>

// Function to find the index of a smaller byte array within a larger byte array
int indexOf(const std::vector<uint8_t>& outerArray, const std::vector<uint8_t>& smallerArray) {
    if (smallerArray.size() > outerArray.size()) {
        return -1;
    }

    for (size_t i = 0; i <= outerArray.size() - smallerArray.size(); ++i) {
        bool found = true;
        for (size_t j = 0; j < smallerArray.size(); ++j) {
            if (outerArray[i + j] != smallerArray[j]) {
                found = false;
                break;
            }
        }
        if (found) {
            return static_cast<int>(i);
        }
    }
    return -1;
}

// Function to delete a file if it exists
void deleteFileIfExists(const std::string& filename) {
    if (DeleteFileA(filename.c_str())) {
        std::cout << "Deleted existing file: " << filename << std::endl;
    }
}

int main(int argc, char* argv[]) {
    try {
        // Default filenames matching the original script behavior
        std::string inputFile = "os.bin";
        std::string outputFile = "cutos.bin";

        // Allow command-line override
        if (argc == 3) {
            inputFile = argv[1];
            outputFile = argv[2];
        }
        else if (argc != 1) {
            std::cerr << "Usage: " << argv[0] << " [input_file] [output_file]" << std::endl;
            std::cerr << "Default: os.bin -> cutos.bin" << std::endl;
            return 1;
        }

        std::cout << "Cutting OS out of RAM dump" << std::endl;
        
        // Delete old output file if it exists
        deleteFileIfExists(outputFile);

        // Read input file
        std::ifstream inFile(inputFile, std::ios::binary);
        if (!inFile) {
            std::cerr << "Error: Cannot open input file: " << inputFile << std::endl;
            return 1;
        }

        // Read all bytes from input file
        std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(inFile)),
                                    std::istreambuf_iterator<char>());
        inFile.close();

        std::cout << "Read " << bytes.size() << " bytes from " << inputFile << std::endl;

        // Pattern to search for (thanks critor)
        std::vector<uint8_t> pattern = {
            0x12, 0x0C, 0xF0, 0x8F, 0x12, 0x0C, 0x00, 0x90, 0x12, 0x0C, 0x10, 0x90, 0x12, 0x0C, 0x00, 0xA0,
            0x1A, 0x0C, 0x00, 0xA4, 0x12, 0x0C, 0x00, 0xAC, 0x12, 0x0C, 0x00, 0xB0, 0x12, 0x0C, 0x00, 0xB4,
            0x12, 0x0C, 0x00, 0xB8, 0x12, 0x0C, 0x00, 0xBC, 0x12, 0x0C, 0x00, 0xC0, 0x12, 0x0C, 0x00, 0xC4,
            0x12, 0x0C, 0x00, 0xC8, 0x12, 0x0C, 0x00, 0xCC, 0x12, 0x0C, 0x00, 0xDC, 0x12, 0x0C, 0x00, 0xA9,
            0x12, 0x0C, 0x00, 0x81, 0x12, 0x0C, 0x10, 0x81, 0x12, 0x0C, 0x20, 0x81, 0x12, 0x0C, 0x30, 0x81,
            0x12, 0x0C, 0x40, 0x81, 0x12, 0x0C, 0x50, 0x81, 0x12, 0x0C, 0x60, 0x81, 0x12, 0x0C, 0x70, 0x81,
            0x12, 0x0C, 0x80, 0x81, 0x12, 0x0C, 0x90, 0x81, 0x12, 0x0C, 0xA0, 0x81, 0x12, 0x0C, 0xB0, 0x81
        };

        // Find pattern in bytes
        std::cout << "Searching for pattern..." << std::endl;
        int patternIndex = indexOf(bytes, pattern);

        if (patternIndex == -1) {
            std::cerr << "Error: Pattern not found in input file" << std::endl;
            return 1;
        }

        std::cout << "Pattern found at index: " << patternIndex << std::endl;

        // Extract bytes from start to end of pattern
        size_t endIndex = patternIndex + pattern.size();
        std::vector<uint8_t> subArray(bytes.begin(), bytes.begin() + endIndex);

        // Write to output file
        std::ofstream outFile(outputFile, std::ios::binary);
        if (!outFile) {
            std::cerr << "Error: Cannot create output file: " << outputFile << std::endl;
            return 1;
        }

        outFile.write(reinterpret_cast<const char*>(subArray.data()), subArray.size());
        outFile.close();

        std::cout << "Successfully wrote " << subArray.size() << " bytes to " << outputFile << std::endl;

        // Clean up: delete the input file after successful processing
        deleteFileIfExists(inputFile);
        
        std::cout << "Dumped " << outputFile << " successfully." << std::endl;

        return 0;
    }
    catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
        return 1;
    }
}
